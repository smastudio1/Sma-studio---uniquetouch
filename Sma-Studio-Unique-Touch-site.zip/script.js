let cart = JSON.parse(localStorage.getItem("smaCart") || "[]");

function saveCart(){localStorage.setItem("smaCart", JSON.stringify(cart)); renderCart();}

function addToCart(name, price, image){
  const item = cart.find(x => x.name === name);
  if(item) item.qty++;
  else cart.push({name, price, image, qty:1});
  saveCart();
  showToast(name + " ajouté au panier");
}

function removeFromCart(name){
  cart = cart.filter(x => x.name !== name);
  saveCart();
}

function renderCart(){
  const count = cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("cartCount").textContent = count;
  const box = document.getElementById("cartItems");
  if(!cart.length){
    box.innerHTML = '<p style="color:#888">Votre panier est vide.</p>';
  } else {
    box.innerHTML = cart.map(x => `
      <div class="cart-row">
        <div><b>${x.name}</b><br><span>${x.qty} × ${x.price} DH</span></div>
        <button class="remove" onclick="removeFromCart('${x.name.replace(/'/g,"\\'")}')">Supprimer</button>
      </div>`).join("");
  }
  document.getElementById("cartTotal").textContent =
    cart.reduce((s,x)=>s+x.price*x.qty,0) + " DH";
}

function openCart(){document.getElementById("cartModal").classList.remove("hidden");renderCart();}
function closeCart(){document.getElementById("cartModal").classList.add("hidden");}

function showToast(msg){
  const t=document.getElementById("toast");
  t.textContent=msg;t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2200);
}

function submitOrder(e){
  e.preventDefault();
  if(!cart.length){showToast("Ajoutez d'abord un parfum au panier");return;}
  const name=document.getElementById("name").value.trim();
  const phone=document.getElementById("phone").value.trim();
  const city=document.getElementById("city").value.trim();
  const note=document.getElementById("note").value.trim();
  const lines=cart.map(x=>`- ${x.name} x${x.qty}: ${x.price*x.qty} DH`).join("\n");
  const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
  const msg=`Bonjour Sma Studio Unique Touch,\n\nJe souhaite commander :\n${lines}\n\nTotal produits : ${total} DH\nNom : ${name}\nTéléphone : ${phone}\nVille : ${city}${note ? `\nNote : ${note}` : ""}`;
  navigator.clipboard?.writeText(msg);
  alert("Commande préparée !\n\nLe message complet a été copié lorsque votre navigateur l'autorise. Il ne reste qu'à l'envoyer à Sma Studio via votre canal de contact.");
}

renderCart();
