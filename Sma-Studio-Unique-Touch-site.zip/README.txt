SMA STUDIO UNIQUE TOUCH — SITE E-COMMERCE

Fichiers :
- index.html : page du site
- style.css : design
- script.js : panier et préparation de commande
- images/ : vos 5 photos

Prix affichés :
- Vanilla Candy : 50 DH
- Blue Man : 50 DH
- Signature Sma Studio : dès 50 DH

IMPORTANT :
Le site est statique : il fonctionne sans serveur et peut être publié gratuitement avec GitHub Pages.
Pour recevoir réellement les commandes sur WhatsApp, remplacez dans script.js la fonction submitOrder par votre numéro WhatsApp, ou dites-moi votre numéro et je peux préparer le bouton WhatsApp directement.

PUBLICATION GITHUB PAGES :
1. Créez un dépôt GitHub (ex. sma-studio-unique-touch).
2. Envoyez index.html, style.css, script.js et le dossier images.
3. Dans Settings > Pages, choisissez Deploy from a branch, puis main / root.
4. GitHub vous donnera le lien public du site.
